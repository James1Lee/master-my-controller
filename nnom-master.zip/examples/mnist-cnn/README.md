This is a very simple convolution example following the Keras tutorial:

https://adventuresinmachinelearning.com/keras-tutorial-cnn-11-lines/

This example is a bit out-dated and is no longer compatible with the current NNoM. 

However, it provides the idea which uses Jupyter Notebook to present the step by step process of training and quantisation of the model.