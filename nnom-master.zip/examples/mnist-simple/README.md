# MNIST-Simple

[中文文档](../../docs/example_mnist_simple_cn.md)


