Please download the MS-SNSD project into this folder. 
https://github.com/microsoft/MS-SNSD