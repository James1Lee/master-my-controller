

def test_script(x,y):
    print("script is included")