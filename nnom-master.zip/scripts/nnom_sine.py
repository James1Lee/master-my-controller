
import os, sys



from tensorflow.keras import *
from tensorflow.keras.datasets import mnist
from tensorflow.keras.layers import *
from tensorflow.keras.models import load_model, save_model

import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import math

###from tensorflow.python.keras import Dense
from tensorflow.keras import layers


import script_test
import nnom_utils
import nnom
import gen_config
import fully_connected_opt_weight_generation

print("nnom_sine - program is starting...")


def train(x_train, y_train, x_test_y_test, batch_size=16, epochs=100):
    inputs = Input(shape=x_train.shape[1:])
    
    print("-------------------------------")
    print("train function activated")
    print("-------------------------------")
    

if __name__ == "__main__":
    epochs = 64
    num_classes = 10
    print("main-function is start")
    
    SAMPLES = 1000
    np.random.seed(1337)
    x_values = np.random.uniform(low=0, high=2*math.pi, size=SAMPLES)
    np.random.shuffle(x_values)
    y_values = np.sin(x_values)
    y_values += 0.1 * np.random.randn(*y_values.shape)
    TRAIN_SPLIT =  int(0.6 * SAMPLES)
    TEST_SPLIT = int(0.2 * SAMPLES + TRAIN_SPLIT)
    x_train, x_test, x_validate = np.split(x_values, [TRAIN_SPLIT, TEST_SPLIT])
    y_train, y_test, y_validate = np.split(y_values, [TRAIN_SPLIT, TEST_SPLIT])
    assert (x_train.size + x_validate.size + x_test.size) ==  SAMPLES
    
    plt.figure(1)
    plt.plot(x_train, y_train, 'b.', label="Train")
    plt.plot(x_test, y_test, 'r.', label="Test")
    plt.plot(x_validate, y_validate, 'y.', label="validate")
    plt.legend()

    
    model_keras = tf.keras.Sequential()
    model_keras.add(layers.Dense(16, activation='relu', input_shape=(1,)))
    model_keras.add(layers.Dense(16, activation='relu'))
    model_keras.add(layers.Dense(1))
    model_keras.compile(optimizer='rmsprop', loss='mse', metrics=['mae'])
    
    history = model_keras.fit(x_train, y_train, epochs=epochs, batch_size=16,
                            validation_data=(x_validate, y_validate))
    
    ###model_keras = load_model()
    ###print(type(x_test), type(y_test))
    nnom.evaluate_model(model_keras, x_test, y_test)
    ###script_test.test_script(1,2)
    
    nnom_utils.generate_model(model_keras, x_test, name="weights.h")
    
    mae = history.history['mae']
    val_mae = history.history['val_mae']
    
    plt.figure(2)
    plt.plot(range(0, epochs), mae, color='red', label='Training mae')
    plt.plot(range(0, epochs), val_mae, color='green', label='Validation mae')
    plt.title('Training and validation mean absolute error')
    plt.xlabel('Epochs')
    plt.ylabel('MAE')
    plt.legend()
    
    plt.figure(3)
    predictions = model_keras.predict(x_train)
    plt.clf()
    plt.title('Train data prediced vs actual values')
    plt.plot(x_test, y_test, 'b.', label='actual')
    plt.plot(x_train, predictions, 'r.', label='predicted')
    plt.legend()
    
    plt.show()
    
    
    
